# Data-Analyst-Project-for-E-Commerce-Company-based-on-Brazil

## Setup environment
```
conda create --name main-ds python=3.9
conda activate main-ds
pip install numpy pandas scipy matplotlib seaborn jupyter streamlit babel scikit-learn

## Dataset
```
Brazilian Olist
https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce

## Run steamlit app
```
streamlit run streamlit_customer_segmentation_dashboard.py
```
